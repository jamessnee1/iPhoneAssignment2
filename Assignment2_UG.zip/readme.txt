Swift Assignment 2 Readme.txt
James Snee s3369721
Heather Ingram s3402200

Our assignment is a Quiz app, containing 30 questions in various categories. It allows the user to read out the question and possible answers to them, just like Who Wants to Be A Millionaire and other quiz shows. It also allows the user to share their progress on social media (Facebook and Twitter), and also saves their progress into an SQLite database, so the app will remember their progress from last time.

Features: 30 Questions in 6 Categories
	  Share progress to Facebook or Twitter
	  Voice accessibility feature
	  SQLite saving of progress
	  Sound effects and music
	  Options to turn music and voice on/off, and to choose voice 
	  type and rate.


Known bugs: Core Data does not work!

References:
http://www.raywenderlich.com/16873/how-to-add-search-into-a-table-view
Used this tutorial as a base for the table view search functionality.

