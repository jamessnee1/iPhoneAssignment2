//
//  Category.swift
//  Quiz Fun
//
//  Created by James Snee on 11/05/2015.
//  Copyright (c) 2015 James Snee and Heather Ingram. All rights reserved.
//

import Foundation

struct Category {

    let categoryName : String
    let categoryDesc : String
    let numOfQuestions : Int
    

}
