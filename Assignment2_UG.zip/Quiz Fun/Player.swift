//
//  Player.swift
//  
//
//  Created by James Snee on 25/05/2015.
//
//

import Foundation
import CoreData

class Player: NSManagedObject {

    @NSManaged var overallquestionsanswered: NSNumber
    @NSManaged var score: NSNumber

}
